<?php
declare(strict_types=1);

$configPath = __DIR__ . '/../api/config.php';
if (!file_exists($configPath)) {
    $alternatePath = __DIR__ . '/../../api/config.php';
    if (file_exists($alternatePath)) {
        $configPath = $alternatePath;
    }
}

if (!file_exists($configPath)) {
    http_response_code(500);
    echo 'Admin config missing.';
    exit;
}

require_once $configPath;

const ADMIN_RATE_LIMIT_MAX = 3;
const ADMIN_RATE_LIMIT_WINDOW = 900;
const ADMIN_RATE_LIMIT_BLOCK = 1800;
const ADMIN_RATE_LIMIT_FILE = DATA_DIR . '/admin_rate_limit.json';

function admin_get_client_ip(): string
{
    $ip = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? '';
    if ($ip !== '') {
        return trim(explode(',', $ip)[0]);
    }
    $forwarded = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? '';
    if ($forwarded !== '') {
        return trim(explode(',', $forwarded)[0]);
    }
    return $_SERVER['REMOTE_ADDR'] ?? 'unknown';
}

function load_admin_rate_state(): array
{
    return read_json_file(ADMIN_RATE_LIMIT_FILE, ['ips' => []]);
}

function normalize_admin_rate_record(array $record, int $now): array
{
    $count = (int) ($record['count'] ?? 0);
    $first = (int) ($record['first'] ?? $now);
    $blockedUntil = (int) ($record['blocked_until'] ?? 0);
    $strikes = (int) ($record['strikes'] ?? 0);
    if ($blockedUntil === -1) {
        return ['count' => $count, 'first' => $first, 'blocked_until' => -1, 'strikes' => $strikes];
    }
    if ($blockedUntil > $now) {
        return ['count' => $count, 'first' => $first, 'blocked_until' => $blockedUntil, 'strikes' => $strikes];
    }
    if (($now - $first) > ADMIN_RATE_LIMIT_WINDOW) {
        return ['count' => 0, 'first' => $now, 'blocked_until' => 0, 'strikes' => $strikes];
    }
    return ['count' => $count, 'first' => $first, 'blocked_until' => $blockedUntil, 'strikes' => $strikes];
}

function record_admin_failure(array $state, string $ip, array $record, int $now): void
{
    $count = (int) ($record['count'] ?? 0) + 1;
    $first = (int) ($record['first'] ?? $now);
    $blockedUntil = (int) ($record['blocked_until'] ?? 0);
    $strikes = (int) ($record['strikes'] ?? 0);
    if ($blockedUntil === -1) {
        return;
    }
    if (($now - $first) > ADMIN_RATE_LIMIT_WINDOW) {
        $count = 1;
        $first = $now;
        $blockedUntil = 0;
    }
    if ($count >= ADMIN_RATE_LIMIT_MAX) {
        if ($strikes >= 1) {
            $blockedUntil = -1;
        } else {
            $blockedUntil = $now + ADMIN_RATE_LIMIT_BLOCK;
            $strikes = 1;
        }
    }
    $state['ips'][$ip] = [
        'count' => $count,
        'first' => $first,
        'blocked_until' => $blockedUntil,
        'strikes' => $strikes,
    ];
    write_json_file(ADMIN_RATE_LIMIT_FILE, $state);
}

function clear_admin_rate_record(array $state, string $ip): void
{
    if (isset($state['ips'][$ip])) {
        unset($state['ips'][$ip]);
        write_json_file(ADMIN_RATE_LIMIT_FILE, $state);
    }
}

function deny_rate_limit(): void
{
    http_response_code(429);
    echo 'Too many attempts. Try again later.';
    exit;
}

function get_basic_auth_credentials(): array
{
    $user = $_SERVER['PHP_AUTH_USER'] ?? '';
    $pass = $_SERVER['PHP_AUTH_PW'] ?? '';
    if ($user !== '' || $pass !== '') {
        return [$user, $pass];
    }
    $header = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
    if ($header === '' && isset($_SERVER['Authorization'])) {
        $header = (string) $_SERVER['Authorization'];
    }
    if ($header !== '' && stripos($header, 'basic ') === 0) {
        $decoded = base64_decode(substr($header, 6), true);
        if ($decoded !== false) {
            $parts = explode(':', $decoded, 2);
            return [$parts[0] ?? '', $parts[1] ?? ''];
        }
    }
    return ['', ''];
}

function deny_admin_access(): void
{
    header('WWW-Authenticate: Basic realm="Booking Admin"');
    http_response_code(401);
    echo 'Unauthorized';
    exit;
}

function require_admin_ui(): void
{
    if (ADMIN_API_KEY === '' || ADMIN_API_KEY === 'change-this-admin-key') {
        http_response_code(500);
        echo 'Admin key not configured.';
        exit;
    }
    $ip = admin_get_client_ip();
    $now = time();
    $state = load_admin_rate_state();
    $record = normalize_admin_rate_record($state['ips'][$ip] ?? [], $now);
    $blockedUntil = (int) ($record['blocked_until'] ?? 0);
    if ($blockedUntil === -1 || $blockedUntil > $now) {
        deny_rate_limit();
    }
    [$user, $pass] = get_basic_auth_credentials();
    $expectedUser = defined('ADMIN_UI_USER') && ADMIN_UI_USER !== '' ? ADMIN_UI_USER : 'admin';
    if ($user === '' || $pass === '') {
        deny_admin_access();
    }
    if (defined('ADMIN_UI_PASSWORD_HASH') && ADMIN_UI_PASSWORD_HASH !== '') {
        if (!hash_equals($expectedUser, (string) $user) || !password_verify($pass, ADMIN_UI_PASSWORD_HASH)) {
            record_admin_failure($state, $ip, $record, $now);
            deny_admin_access();
        }
        clear_admin_rate_record($state, $ip);
        return;
    }
    if (!hash_equals($expectedUser, (string) $user) || !hash_equals(ADMIN_API_KEY, (string) $pass)) {
        record_admin_failure($state, $ip, $record, $now);
        deny_admin_access();
    }
    clear_admin_rate_record($state, $ip);
}

require_admin_ui();
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Van Booking Admin</title>
    <style>
      :root {
        --bg: #fff5fb;
        --bg-2: #ffe3f2;
        --ink: #12040a;
        --pink: #ff2d93;
        --hot: #ff006e;
        --line: rgba(255, 0, 110, 0.25);
        --shadow: rgba(255, 0, 110, 0.2);
        --mono: "Courier Prime", "IBM Plex Mono", "Courier New", Courier, monospace;
        --bubble: "Baloo 2", "Cooper Black", "Bookman Old Style", "Georgia", serif;
      }

      * {
        box-sizing: border-box;
      }

      body {
        margin: 0;
        font-family: var(--mono);
        color: var(--ink);
        background: radial-gradient(circle at 15% 10%, #ffe1f0 0%, #fff5fb 45%, #fff 100%);
      }

      header {
        max-width: 1100px;
        margin: 0 auto;
        padding: 48px 24px 24px;
      }

      h1 {
        font-family: var(--bubble);
        color: var(--hot);
        margin: 0 0 8px;
        font-size: clamp(2.2rem, 4vw, 3.4rem);
      }

      .subtitle {
        margin: 0;
        color: #55122b;
        font-size: 1rem;
      }

      main {
        max-width: 1100px;
        margin: 0 auto;
        padding: 0 24px 64px;
      }

      section {
        background: #fff;
        border: 1px solid var(--line);
        border-radius: 22px;
        padding: 20px;
        margin-bottom: 20px;
        box-shadow: 0 16px 32px var(--shadow);
      }

      h2 {
        margin: 0 0 12px;
        font-size: 1rem;
        letter-spacing: 0.2em;
        text-transform: uppercase;
        color: var(--hot);
      }

      label {
        display: block;
        font-size: 0.75rem;
        text-transform: uppercase;
        letter-spacing: 0.16em;
        margin-bottom: 6px;
        color: #6b173f;
      }

      input,
      select,
      button,
      textarea {
        font-family: var(--mono);
      }

      input,
      select,
      textarea {
        width: 100%;
        padding: 10px 12px;
        border-radius: 12px;
        border: 1px solid rgba(255, 0, 110, 0.3);
        background: #fff9fc;
        color: var(--ink);
      }

      .grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 16px;
      }

      .editor-list {
        display: grid;
        gap: 12px;
      }

      .editor-row {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr)) auto;
        gap: 12px;
        align-items: end;
      }

      .editor-row.gallery {
        grid-template-columns: minmax(0, 2fr) minmax(0, 1fr) minmax(0, 140px) auto;
      }

      .gallery-preview {
        width: 120px;
        height: 90px;
        border-radius: 12px;
        border: 1px solid rgba(255, 0, 110, 0.2);
        overflow: hidden;
        background: #fff5fb;
        display: flex;
        align-items: center;
        justify-content: center;
      }

      .gallery-thumb {
        width: 100%;
        height: 100%;
        object-fit: cover;
      }

      .gallery-thumb.broken {
        object-fit: contain;
        opacity: 0.4;
      }

      .span-2 {
        grid-column: 1 / -1;
      }

      .row {
        display: flex;
        flex-wrap: wrap;
        gap: 12px;
        align-items: center;
      }

      #recurringDays label {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        font-size: 0.8rem;
        color: #5f173a;
      }

      .btn {
        padding: 10px 16px;
        border-radius: 999px;
        border: none;
        background: linear-gradient(135deg, #ff2d93, #ff006e);
        color: #fff;
        text-transform: uppercase;
        letter-spacing: 0.1em;
        font-size: 0.8rem;
        cursor: pointer;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        justify-content: center;
      }

      .btn.secondary {
        background: #fff;
        color: var(--hot);
        border: 1px solid var(--hot);
      }

      .btn.ghost {
        background: transparent;
        border: 1px dashed var(--hot);
        color: var(--hot);
      }

      .status {
        font-size: 0.85rem;
        color: #7a1c45;
      }

      .request-card {
        border: 1px solid var(--line);
        border-radius: 18px;
        padding: 16px;
        margin-bottom: 16px;
        background: #fffafb;
      }

      .request-header {
        display: flex;
        flex-wrap: wrap;
        gap: 12px;
        align-items: center;
        justify-content: space-between;
      }

      .request-badges {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        align-items: center;
      }

      .badge {
        padding: 6px 10px;
        border-radius: 999px;
        font-size: 0.7rem;
        text-transform: uppercase;
        letter-spacing: 0.12em;
        border: 1px solid var(--line);
        background: #fff;
      }

      .badge.pending {
        color: #b53a6b;
      }

      .badge.accepted {
        color: #b8741a;
        border-color: rgba(184, 116, 26, 0.35);
        background: #fff3e3;
      }

      .badge.declined,
      .badge.cancelled {
        color: #a33434;
      }

      .badge.paid {
        color: #1a7f4f;
        border-color: rgba(26, 127, 79, 0.35);
        background: #e6f6ed;
      }

      .badge.blacklisted {
        color: #fff;
        border-color: rgba(88, 0, 18, 0.65);
        background: linear-gradient(135deg, #7a0018, #3b0010);
      }

      .meta {
        font-size: 0.85rem;
        color: #5f173a;
        margin: 6px 0 0;
      }

      .actions {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        margin-top: 12px;
      }

      .hint {
        font-size: 0.8rem;
        color: #7a1c45;
      }

      .hidden {
        display: none;
      }

      .calendar {
        border: 1px solid var(--line);
        border-radius: 16px;
        background: #fffafb;
        padding: 12px;
        overflow: auto;
        max-height: 520px;
      }

      .calendar-grid {
        display: grid;
        gap: 4px;
        min-width: 720px;
      }

      .calendar-cell {
        padding: 6px 8px;
        border-radius: 8px;
        border: 1px solid rgba(255, 0, 110, 0.12);
        background: #fff;
        font-size: 0.72rem;
        text-align: center;
        color: #57122c;
      }

      .calendar-head {
        background: #ffe6f3;
        color: #b01d63;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.08em;
      }

      .calendar-time {
        background: #fff5fb;
        font-weight: 600;
      }

      .calendar-slot {
        cursor: pointer;
        transition: background 0.15s ease, transform 0.15s ease;
        min-height: 26px;
      }

      .calendar-slot:hover {
        background: rgba(255, 0, 110, 0.08);
        transform: translateY(-1px);
      }

      .calendar-slot.blocked {
        background: linear-gradient(135deg, rgba(255, 45, 147, 0.9), rgba(255, 0, 110, 0.9));
        color: #fff;
        border-color: rgba(255, 0, 110, 0.5);
      }

      .calendar-slot.recurring {
        background: #ffeef6;
        border-style: dashed;
      }

      .calendar-slot.booking {
        background: #ffe7c2;
        color: #6b3a00;
        border-color: rgba(184, 116, 26, 0.35);
        font-weight: 600;
      }

      .calendar-slot.booking.outcall {
        background: #dbe7ff;
        color: #23345a;
        border-color: rgba(35, 52, 90, 0.25);
      }

      .calendar-slot.booking.paid {
        box-shadow: inset 0 0 0 2px rgba(26, 127, 79, 0.35);
      }

      .calendar-legend {
        display: flex;
        gap: 12px;
        align-items: center;
        font-size: 0.8rem;
        color: #6b173f;
      }

      .calendar-controls {
        flex-wrap: wrap;
        gap: 12px;
      }

      .segmented {
        display: inline-flex;
        border: 1px solid var(--line);
        border-radius: 999px;
        overflow: hidden;
        background: #fff;
      }

      .seg-btn {
        border: none;
        padding: 8px 16px;
        background: transparent;
        font-size: 0.85rem;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        color: #6b173f;
        cursor: pointer;
      }

      .seg-btn[aria-pressed="true"] {
        background: linear-gradient(135deg, #ff2d93, #ff006e);
        color: #fff;
      }

      .calendar-field {
        min-width: 200px;
      }

      .calendar-field[hidden] {
        display: none;
      }

      .calendar-grid.month {
        grid-template-columns: repeat(7, minmax(90px, 1fr));
      }

      .calendar-grid.month .month-cell {
        border: 1px solid rgba(255, 0, 110, 0.18);
        border-radius: 12px;
        padding: 10px;
        min-height: 90px;
        display: flex;
        flex-direction: column;
        gap: 6px;
      }

      .month-cell.muted {
        opacity: 0.35;
      }

      .month-day {
        font-weight: 700;
        color: #55122b;
      }

      .month-badges {
        display: flex;
        flex-wrap: wrap;
        gap: 6px;
      }

      .month-badge {
        font-size: 0.7rem;
        padding: 2px 6px;
        border-radius: 999px;
        border: 1px solid rgba(255, 0, 110, 0.28);
        background: rgba(255, 0, 110, 0.08);
      }

      .month-badge.booking {
        background: #ffe7c2;
        border-color: rgba(184, 116, 26, 0.35);
      }

      .month-badge.paid {
        background: #e6f6ed;
        border-color: rgba(26, 127, 79, 0.35);
      }

      .month-badge.blocked {
        background: linear-gradient(135deg, #ff2d93, #ff006e);
        border-color: rgba(255, 0, 110, 0.6);
        color: #fff;
      }

      .legend-dot {
        width: 12px;
        height: 12px;
        border-radius: 50%;
        background: rgba(255, 0, 110, 0.15);
        border: 1px solid rgba(255, 0, 110, 0.35);
      }

      .legend-dot.blocked {
        background: linear-gradient(135deg, #ff2d93, #ff006e);
        border-color: rgba(255, 0, 110, 0.6);
      }

      .legend-dot.booking {
        background: #ffe7c2;
        border-color: rgba(184, 116, 26, 0.35);
      }

      .legend-dot.outcall {
        background: #dbe7ff;
        border-color: rgba(35, 52, 90, 0.25);
      }

      .legend-dot.paid {
        background: #e6f6ed;
        border-color: rgba(26, 127, 79, 0.35);
      }

      @media (max-width: 900px) {
        .grid {
          grid-template-columns: 1fr;
        }
      }
    </style>
  </head>
  <body>
    <header>
      <h1>Van Booking Admin</h1>
      <p class="subtitle">Accept + confirm paid requests to auto-block the calendar. Simple weekly view + save.</p>
    </header>

    <main>
      <section>
        <h2>Availability</h2>
        <div class="grid">
          <div class="field">
            <label for="tourCity">Touring city</label>
            <input id="tourCity" type="text" />
          </div>
          <div class="field">
            <label for="tourTimezone">Touring time zone</label>
            <select id="tourTimezone"></select>
          </div>
          <div class="field">
            <label for="bufferMinutes">Buffer minutes</label>
            <input id="bufferMinutes" type="number" min="0" max="240" step="5" />
          </div>
        </div>
        <div class="row">
          <button class="btn" id="saveAvailability">Save availability</button>
          <span class="status" id="availabilityStatus"></span>
        </div>
      </section>

      <section>
        <h2>Schedule overview</h2>
        <div class="row calendar-controls">
          <div class="segmented" role="tablist" aria-label="Calendar views">
            <button class="seg-btn" type="button" data-calendar-view="day" aria-pressed="false">Day</button>
            <button class="seg-btn" type="button" data-calendar-view="week" aria-pressed="true">Week</button>
            <button class="seg-btn" type="button" data-calendar-view="month" aria-pressed="false">Month</button>
          </div>
          <div class="field calendar-field" data-calendar-field="day" hidden>
            <label for="calendarDay">Day (touring time)</label>
            <input id="calendarDay" type="date" />
          </div>
          <div class="field calendar-field" data-calendar-field="week">
            <label for="calendarStart">Week of (touring time)</label>
            <input id="calendarStart" type="date" />
          </div>
          <div class="field calendar-field" data-calendar-field="month" hidden>
            <label for="calendarMonth">Month (touring time)</label>
            <input id="calendarMonth" type="month" />
          </div>
          <button class="btn ghost" id="calendarToday" type="button">Today</button>
        </div>
        <div class="calendar">
          <div class="calendar-grid" id="calendarGrid"></div>
        </div>
        <div class="calendar-legend">
          <span><span class="legend-dot blocked"></span>Manual block</span>
          <span><span class="legend-dot booking"></span>Paid booking</span>
          <span><span class="legend-dot outcall"></span>Outcall</span>
        </div>
      </section>

      <section>
        <h2>Blocked slots</h2>
        <div class="grid">
          <div class="field">
            <label for="blockedDate">Date (touring time)</label>
            <input id="blockedDate" type="date" />
          </div>
          <div class="field">
            <label for="blockedStart">Start time</label>
            <input id="blockedStart" type="time" />
          </div>
          <div class="field">
            <label for="blockedEnd">End time</label>
            <input id="blockedEnd" type="time" />
          </div>
          <div class="field">
            <label for="blockedReason">Reason (optional)</label>
            <input id="blockedReason" type="text" />
          </div>
        </div>
        <div class="row">
          <button class="btn secondary" id="addBlocked">Add blocked slot</button>
          <button class="btn ghost" id="blockFullDay" type="button">Block full day</button>
          <span class="status" id="blockedStatus"></span>
        </div>
        <div class="grid">
          <div class="field">
            <label for="blockedFullRangeStart">Block full days from</label>
            <input id="blockedFullRangeStart" type="date" />
          </div>
          <div class="field">
            <label for="blockedFullRangeEnd">Block full days to</label>
            <input id="blockedFullRangeEnd" type="date" />
          </div>
        </div>
        <div class="row">
          <button class="btn ghost" id="blockFullRange" type="button">Block full days range</button>
        </div>
        <div class="grid">
          <div class="field span-2">
            <label>Recurring days</label>
            <div class="row" id="recurringDays">
              <label><input type="checkbox" value="0" /> Sun</label>
              <label><input type="checkbox" value="1" /> Mon</label>
              <label><input type="checkbox" value="2" /> Tue</label>
              <label><input type="checkbox" value="3" /> Wed</label>
              <label><input type="checkbox" value="4" /> Thu</label>
              <label><input type="checkbox" value="5" /> Fri</label>
              <label><input type="checkbox" value="6" /> Sat</label>
            </div>
          </div>
          <div class="field">
            <label for="recurringAllDay">All day</label>
            <input id="recurringAllDay" type="checkbox" />
          </div>
          <div class="field">
            <label for="recurringStart">Recurring start</label>
            <input id="recurringStart" type="time" />
          </div>
          <div class="field">
            <label for="recurringEnd">Recurring end</label>
            <input id="recurringEnd" type="time" />
          </div>
          <div class="field span-2">
            <label for="recurringReason">Recurring reason (optional)</label>
            <input id="recurringReason" type="text" />
          </div>
        </div>
        <div class="row">
          <button class="btn ghost" id="addRecurring" type="button">Add recurring block</button>
          <span class="status" id="recurringStatus"></span>
        </div>
        <div id="recurringList" class="hint"></div>
        <div class="grid">
          <div class="field">
            <label for="blockedRangeStart">Block from (date + time)</label>
            <input id="blockedRangeStart" type="datetime-local" />
          </div>
          <div class="field">
            <label for="blockedRangeEnd">Block to (date + time)</label>
            <input id="blockedRangeEnd" type="datetime-local" />
          </div>
          <div class="field span-2">
            <label for="blockedRangeReason">Range reason (optional)</label>
            <input id="blockedRangeReason" type="text" />
          </div>
        </div>
        <div class="row">
          <button class="btn secondary" id="blockRange" type="button">Block date/time range</button>
          <span class="status" id="blockedRangeStatus"></span>
        </div>
        <div class="row">
          <button class="btn ghost" id="toggleBlockedList" type="button">Show blocked slots</button>
        </div>
        <div id="blockedList" class="hint hidden"></div>
      </section>

      <section>
        <h2>Tour schedule</h2>
        <div class="editor-list" id="tourScheduleList"></div>
        <p class="hint">Dates are inclusive. Use YYYY-MM-DD and avoid overlaps.</p>
        <div class="row">
          <button class="btn secondary" id="addTourRow" type="button">Add stop</button>
          <button class="btn" id="saveTourSchedule" type="button">Save tour schedule</button>
          <span class="status" id="tourScheduleStatus"></span>
        </div>
      </section>

      <section>
        <h2>Eye candy</h2>
        <div class="editor-list" id="galleryList"></div>
        <p class="hint">Use full paths like /photos/heidi15.jpg and short alt text.</p>
        <div class="row">
          <button class="btn secondary" id="addGalleryRow" type="button">Add eye candy</button>
          <button class="btn" id="saveGallery" type="button">Save eye candy</button>
          <span class="status" id="galleryStatus"></span>
        </div>
      </section>

      <section>
        <h2>Requests</h2>
        <div class="row">
          <button class="btn secondary" id="refreshRequests">Refresh</button>
          <select id="statusFilter">
            <option value="all">All</option>
            <option value="pending" selected>Pending</option>
            <option value="accepted">Accepted</option>
            <option value="paid">Paid</option>
            <option value="blacklisted">Blacklisted</option>
            <option value="declined">Declined</option>
            <option value="cancelled">Cancelled</option>
          </select>
          <span class="status" id="requestsStatus"></span>
        </div>
        <div id="requestsList"></div>
        <div class="row">
          <a class="btn ghost" href="customers.php">Costumer directory</a>
        </div>
      </section>
    </main>

    <script>
      const ADMIN_KEY = <?php echo json_encode(ADMIN_API_KEY); ?>;
      const TIMEZONES = [
        "America/Toronto",
        "America/New_York",
        "America/Chicago",
        "America/Denver",
        "America/Los_Angeles",
        "America/Vancouver",
        "America/Mexico_City",
        "America/Sao_Paulo",
        "Europe/London",
        "Europe/Paris",
        "Europe/Berlin",
        "Europe/Rome",
        "Europe/Madrid",
        "Europe/Amsterdam",
        "Europe/Zurich",
        "Europe/Stockholm",
        "Europe/Athens",
        "Europe/Moscow",
        "Africa/Cairo",
        "Africa/Johannesburg",
        "Asia/Dubai",
        "Asia/Jerusalem",
        "Asia/Kolkata",
        "Asia/Bangkok",
        "Asia/Singapore",
        "Asia/Shanghai",
        "Asia/Hong_Kong",
        "Asia/Tokyo",
        "Asia/Seoul",
        "Australia/Sydney",
        "Australia/Melbourne",
        "Pacific/Auckland",
      ];

      const tourCityInput = document.getElementById("tourCity");
      const tourTzSelect = document.getElementById("tourTimezone");
      const bufferInput = document.getElementById("bufferMinutes");
      const availabilityStatus = document.getElementById("availabilityStatus");
      const saveAvailabilityBtn = document.getElementById("saveAvailability");
      const calendarStart = document.getElementById("calendarStart");
      const calendarDay = document.getElementById("calendarDay");
      const calendarMonth = document.getElementById("calendarMonth");
      const calendarToday = document.getElementById("calendarToday");
      const calendarGrid = document.getElementById("calendarGrid");
      const calendarViewButtons = document.querySelectorAll("[data-calendar-view]");
      const calendarFields = document.querySelectorAll("[data-calendar-field]");
      const blockedDate = document.getElementById("blockedDate");
      const blockedStart = document.getElementById("blockedStart");
      const blockedEnd = document.getElementById("blockedEnd");
      const blockedReason = document.getElementById("blockedReason");
      const blockedFullRangeStart = document.getElementById("blockedFullRangeStart");
      const blockedFullRangeEnd = document.getElementById("blockedFullRangeEnd");
      const blockedStatus = document.getElementById("blockedStatus");
      const blockedList = document.getElementById("blockedList");
      const addBlockedBtn = document.getElementById("addBlocked");
      const blockFullDayBtn = document.getElementById("blockFullDay");
      const blockFullRangeBtn = document.getElementById("blockFullRange");
      const recurringDays = document.getElementById("recurringDays");
      const recurringAllDay = document.getElementById("recurringAllDay");
      const recurringStart = document.getElementById("recurringStart");
      const recurringEnd = document.getElementById("recurringEnd");
      const recurringReason = document.getElementById("recurringReason");
      const addRecurringBtn = document.getElementById("addRecurring");
      const recurringStatus = document.getElementById("recurringStatus");
      const recurringList = document.getElementById("recurringList");
      const toggleBlockedListBtn = document.getElementById("toggleBlockedList");
      const refreshBtn = document.getElementById("refreshRequests");
      const statusFilter = document.getElementById("statusFilter");
      const requestsList = document.getElementById("requestsList");
      const requestsStatus = document.getElementById("requestsStatus");
      const tourScheduleList = document.getElementById("tourScheduleList");
      const tourScheduleStatus = document.getElementById("tourScheduleStatus");
      const addTourRowBtn = document.getElementById("addTourRow");
      const saveTourScheduleBtn = document.getElementById("saveTourSchedule");
      const galleryList = document.getElementById("galleryList");
      const galleryStatus = document.getElementById("galleryStatus");
      const addGalleryRowBtn = document.getElementById("addGalleryRow");
      const saveGalleryBtn = document.getElementById("saveGallery");

      if (statusFilter) {
        statusFilter.value = "pending";
      }

      const getKey = () => ADMIN_KEY;

      const headersWithKey = () => {
        const key = getKey();
        if (!key) return {};
        return { "X-Admin-Key": key };
      };

      const populateTimezones = () => {
        tourTzSelect.innerHTML = "";
        TIMEZONES.forEach((zone) => {
          const option = document.createElement("option");
          option.value = zone;
          option.textContent = zone.replace("_", " ");
          tourTzSelect.appendChild(option);
        });
      };

      let blockedSlots = [];
      let recurringBlocks = [];
      const SLOT_MINUTES = 30;
      const SLOT_TIMES = Array.from({ length: 48 }, (_, index) => {
        const total = index * SLOT_MINUTES;
        const hour = String(Math.floor(total / 60)).padStart(2, "0");
        const minute = String(total % 60).padStart(2, "0");
        return `${hour}:${minute}`;
      });

      const timeToMinutes = (timeValue) => {
        const [hour, minute] = String(timeValue || "").split(":").map((value) => Number(value));
        if (Number.isNaN(hour) || Number.isNaN(minute)) return null;
        return hour * 60 + minute;
      };

      const minutesToTime = (minutes) => {
        const hour = String(Math.floor(minutes / 60)).padStart(2, "0");
        const minute = String(minutes % 60).padStart(2, "0");
        return `${hour}:${minute}`;
      };

      const toDateKey = (date) => {
        const year = String(date.getUTCFullYear()).padStart(4, "0");
        const month = String(date.getUTCMonth() + 1).padStart(2, "0");
        const day = String(date.getUTCDate()).padStart(2, "0");
        return `${year}-${month}-${day}`;
      };

      const parseDateKey = (value) => {
        const parts = String(value || "").split("-").map((piece) => Number(piece));
        if (parts.length !== 3) return null;
        const [year, month, day] = parts;
        if (!year || !month || !day) return null;
        return new Date(Date.UTC(year, month - 1, day));
      };

      const blockFullDayForDate = (dateKey, reason) => {
        blockedSlots = blockedSlots.filter((slot) => slot.date !== dateKey);
        const endOfDayMinutes = 24 * 60;
        for (let minutes = 0; minutes < endOfDayMinutes; minutes += SLOT_MINUTES) {
          const next = Math.min(minutes + SLOT_MINUTES, endOfDayMinutes);
          const endTime = next === endOfDayMinutes ? "23:59" : minutesToTime(next);
          blockedSlots.push({
            date: dateKey,
            start: minutesToTime(minutes),
            end: endTime,
            reason,
            kind: "manual",
          });
        }
      };

      const normalizeBlockedSlots = (slots) => {
        const normalized = [];
        (Array.isArray(slots) ? slots : []).forEach((slot) => {
          if (!slot || !slot.date || !slot.start || !slot.end) return;
          const startMinutes = timeToMinutes(slot.start);
          const endMinutes = timeToMinutes(slot.end);
          if (startMinutes === null || endMinutes === null || endMinutes <= startMinutes) return;
          const kind = slot.kind || "manual";
          const bookingType = slot.booking_type || "";
          const bookingStatus = slot.booking_status || "";
          const label = slot.label || "";
          for (let minutes = startMinutes; minutes < endMinutes; minutes += SLOT_MINUTES) {
            normalized.push({
              date: slot.date,
              start: minutesToTime(minutes),
              end: minutesToTime(Math.min(minutes + SLOT_MINUTES, endMinutes)),
              reason: slot.reason || "",
              kind,
              booking_type: bookingType,
              booking_status: bookingStatus,
              label,
              booking_id: slot.booking_id || "",
            });
          }
        });
        return normalized;
      };

      const getDateKey = (date) => {
        const parts = new Intl.DateTimeFormat("en-CA", {
          timeZone: tourTzSelect.value,
          year: "numeric",
          month: "2-digit",
          day: "2-digit",
        }).formatToParts(date);
        const values = Object.fromEntries(parts.map((part) => [part.type, part.value]));
        return `${values.year}-${values.month}-${values.day}`;
      };

      const getWeekDates = (startKey) => {
        const [year, month, day] = startKey.split("-").map((value) => Number(value));
        const base = new Date(Date.UTC(year, month - 1, day));
        return Array.from({ length: 7 }, (_, index) => {
          const date = new Date(base.getTime() + index * 86400000);
          const y = String(date.getUTCFullYear()).padStart(4, "0");
          const m = String(date.getUTCMonth() + 1).padStart(2, "0");
          const d = String(date.getUTCDate()).padStart(2, "0");
          return `${y}-${m}-${d}`;
        });
      };

      const formatDayLabel = (dateKey) => {
        const [year, month, day] = dateKey.split("-").map((value) => Number(value));
        const labelDate = new Date(Date.UTC(year, month - 1, day, 12, 0));
        return new Intl.DateTimeFormat("en-US", {
          timeZone: tourTzSelect.value,
          weekday: "short",
          month: "short",
          day: "numeric",
        }).format(labelDate);
      };

      const getWeekdayIndex = (dateKey) => {
        const parts = dateKey.split("-").map((value) => Number(value));
        if (parts.length !== 3) return 0;
        const labelDate = new Date(Date.UTC(parts[0], parts[1] - 1, parts[2], 12, 0));
        const label = new Intl.DateTimeFormat("en-US", {
          timeZone: tourTzSelect.value,
          weekday: "short",
        }).format(labelDate);
        const map = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };
        return map[label] ?? 0;
      };

      const isRecurringSlot = (dateKey, timeValue) => {
        if (!Array.isArray(recurringBlocks) || !recurringBlocks.length) return false;
        const targetMinutes = timeToMinutes(timeValue);
        if (targetMinutes === null) return false;
        const weekdayIndex = getWeekdayIndex(dateKey);
        return recurringBlocks.some((block) => {
          if (!block) return false;
          const days = Array.isArray(block.days) ? block.days : [];
          if (!days.includes(weekdayIndex)) return false;
          if (block.all_day) return true;
          const startMinutes = timeToMinutes(block.start);
          const endMinutes = timeToMinutes(block.end);
          if (startMinutes === null || endMinutes === null) return false;
          return targetMinutes >= startMinutes && targetMinutes < endMinutes;
        });
      };

      const getSlotEntry = (dateKey, timeValue) => {
        const targetMinutes = timeToMinutes(timeValue);
        if (targetMinutes === null) return null;
        let entry = null;
        blockedSlots.forEach((slot) => {
          if (!slot || slot.date !== dateKey) return;
          const startMinutes = timeToMinutes(slot.start);
          const endMinutes = timeToMinutes(slot.end);
          if (startMinutes === null || endMinutes === null) return;
          if (targetMinutes >= startMinutes && targetMinutes < endMinutes) {
            if (!entry || (entry.kind !== "booking" && slot.kind === "booking")) {
              entry = slot;
            }
          }
        });
        return entry;
      };

      const buildBookingStartMap = () => {
        const map = {};
        blockedSlots.forEach((slot) => {
          if (!slot || slot.kind !== "booking") return;
          const key = slot.booking_id || slot.label || "";
          if (!key) return;
          const value = `${slot.date} ${slot.start}`;
          if (!map[key] || value < map[key]) {
            map[key] = value;
          }
        });
        return map;
      };

      let calendarView = "week";

      const setCalendarView = (view) => {
        calendarView = view;
        calendarViewButtons.forEach((btn) => {
          btn.setAttribute("aria-pressed", btn.dataset.calendarView === view ? "true" : "false");
        });
        calendarFields.forEach((field) => {
          field.hidden = field.dataset.calendarField !== view;
        });
        renderCalendarView();
      };

      const renderTimeGrid = (dates) => {
        const bookingStartMap = buildBookingStartMap();
        calendarGrid.innerHTML = "";
        calendarGrid.classList.remove("month");
        calendarGrid.style.gridTemplateColumns = `90px repeat(${dates.length}, minmax(90px, 1fr))`;

        const headCell = document.createElement("div");
        headCell.className = "calendar-cell calendar-head";
        headCell.textContent = "Time";
        calendarGrid.appendChild(headCell);

        dates.forEach((dateKey) => {
          const cell = document.createElement("div");
          cell.className = "calendar-cell calendar-head";
          cell.dataset.date = dateKey;
          cell.textContent = formatDayLabel(dateKey);
          calendarGrid.appendChild(cell);
        });

        SLOT_TIMES.forEach((timeValue) => {
          const timeCell = document.createElement("div");
          timeCell.className = "calendar-cell calendar-time";
          timeCell.textContent = timeValue;
          calendarGrid.appendChild(timeCell);

          dates.forEach((dateKey) => {
            const slotButton = document.createElement("button");
            slotButton.type = "button";
            slotButton.className = "calendar-cell calendar-slot";
            slotButton.dataset.date = dateKey;
            slotButton.dataset.time = timeValue;
            const entry = getSlotEntry(dateKey, timeValue);
            if (entry) {
              if (entry.kind === "booking") {
                slotButton.classList.add("booking");
                if (entry.booking_type === "outcall") {
                  slotButton.classList.add("outcall");
                }
                if (entry.booking_status === "paid") {
                  slotButton.classList.add("paid");
                }
                const key = entry.booking_id || entry.label || "";
                const startKey = key ? bookingStartMap[key] : "";
                if (key && startKey === `${entry.date} ${entry.start}`) {
                  slotButton.textContent = entry.label || "Booked";
                }
                const titleLabel = entry.label ? `${entry.label} - ` : "";
                slotButton.title = `${titleLabel}${entry.booking_type || "incall"} (${entry.booking_status || "paid"})`;
                slotButton.disabled = true;
              } else {
                slotButton.classList.add("blocked");
                slotButton.title = entry.reason || "Blocked";
              }
            } else if (isRecurringSlot(dateKey, timeValue)) {
              slotButton.classList.add("blocked");
              slotButton.classList.add("recurring");
              slotButton.title = "Recurring block";
            }
            slotButton.addEventListener("click", () => {
              if (entry && entry.kind === "booking") {
                return;
              }
              const start = timeValue;
              const end = minutesToTime(timeToMinutes(timeValue) + SLOT_MINUTES);
              const index = blockedSlots.findIndex(
                (slot) => slot.date === dateKey && slot.start === start && slot.end === end && slot.kind !== "booking"
              );
              if (index >= 0) {
                blockedSlots.splice(index, 1);
              } else {
                blockedSlots.push({ date: dateKey, start, end, reason: "", kind: "manual" });
              }
              renderBlockedSlots();
              renderCalendarView();
              queueAutoSave();
            });
            calendarGrid.appendChild(slotButton);
          });
        });
      };

      const renderWeekCalendar = () => {
        if (!calendarGrid || !calendarStart) return;
        const startKey = calendarStart.value || getDateKey(new Date());
        const dates = getWeekDates(startKey);
        renderTimeGrid(dates);
      };

      const renderDayCalendar = () => {
        if (!calendarGrid || !calendarDay) return;
        const dayKey = calendarDay.value || getDateKey(new Date());
        renderTimeGrid([dayKey]);
      };

      const getMonthGrid = (year, monthIndex) => {
        const first = new Date(Date.UTC(year, monthIndex, 1));
        const startDay = first.getUTCDay();
        const daysInMonth = new Date(Date.UTC(year, monthIndex + 1, 0)).getUTCDate();
        const totalCells = Math.ceil((startDay + daysInMonth) / 7) * 7;
        return Array.from({ length: totalCells }, (_, index) => {
          const day = index - startDay + 1;
          if (day < 1 || day > daysInMonth) return null;
          const month = String(monthIndex + 1).padStart(2, "0");
          const date = String(day).padStart(2, "0");
          return `${year}-${month}-${date}`;
        });
      };

      const getDaySummary = (dateKey) => {
        const bookingIds = new Set();
        const paidIds = new Set();
        let hasManual = false;
        blockedSlots.forEach((slot) => {
          if (!slot || slot.date !== dateKey) return;
          if (slot.kind === "booking") {
            const key = slot.booking_id || `${slot.label}-${slot.start}`;
            bookingIds.add(key);
            if (slot.booking_status === "paid") {
              paidIds.add(key);
            }
            return;
          }
          hasManual = true;
        });
        const weekdayIndex = getWeekdayIndex(dateKey);
        const hasRecurring = recurringBlocks.some((block) => {
          if (!block) return false;
          const days = Array.isArray(block.days) ? block.days : [];
          if (!days.includes(weekdayIndex)) return false;
          if (block.all_day) return true;
          const startMinutes = timeToMinutes(block.start);
          const endMinutes = timeToMinutes(block.end);
          return startMinutes !== null && endMinutes !== null;
        });
        return {
          bookings: bookingIds.size,
          paid: paidIds.size,
          manual: hasManual,
          recurring: hasRecurring,
        };
      };

      const renderMonthCalendar = () => {
        if (!calendarGrid || !calendarMonth) return;
        const monthValue = calendarMonth.value || getDateKey(new Date()).slice(0, 7);
        const [yearStr, monthStr] = monthValue.split("-");
        const year = Number(yearStr);
        const monthIndex = Number(monthStr) - 1;
        if (!year || Number.isNaN(monthIndex)) return;
        calendarGrid.innerHTML = "";
        calendarGrid.classList.add("month");

        const weekdays = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
        weekdays.forEach((label) => {
          const head = document.createElement("div");
          head.className = "calendar-cell calendar-head";
          head.textContent = label;
          calendarGrid.appendChild(head);
        });

        const cells = getMonthGrid(year, monthIndex);
        cells.forEach((dateKey) => {
          const cell = document.createElement("div");
          cell.className = "month-cell";
          if (!dateKey) {
            cell.classList.add("muted");
            calendarGrid.appendChild(cell);
            return;
          }
          const dayNumber = Number(dateKey.split("-")[2]);
          const dayLabel = document.createElement("div");
          dayLabel.className = "month-day";
          dayLabel.textContent = String(dayNumber);
          cell.appendChild(dayLabel);

          const summary = getDaySummary(dateKey);
          const badgeWrap = document.createElement("div");
          badgeWrap.className = "month-badges";
          if (summary.bookings > 0) {
            const badge = document.createElement("span");
            badge.className = "month-badge booking";
            badge.textContent = `Bookings ${summary.bookings}`;
            badgeWrap.appendChild(badge);
          }
          if (summary.paid > 0) {
            const badge = document.createElement("span");
            badge.className = "month-badge paid";
            badge.textContent = `Paid ${summary.paid}`;
            badgeWrap.appendChild(badge);
          }
          if (summary.manual || summary.recurring) {
            const badge = document.createElement("span");
            badge.className = "month-badge blocked";
            badge.textContent = "Blocked";
            badgeWrap.appendChild(badge);
          }
          if (badgeWrap.childElementCount > 0) {
            cell.appendChild(badgeWrap);
          }
          cell.addEventListener("click", () => {
            if (calendarDay) {
              calendarDay.value = dateKey;
            }
            setCalendarView("day");
          });
          calendarGrid.appendChild(cell);
        });
      };

      const renderCalendarView = () => {
        if (!calendarGrid) return;
        if (calendarView === "day") {
          renderDayCalendar();
          return;
        }
        if (calendarView === "month") {
          renderMonthCalendar();
          return;
        }
        renderWeekCalendar();
      };

      const renderBlockedSlots = () => {
        const manualSlots = blockedSlots
          .map((slot, index) => ({ slot, index }))
          .filter(({ slot }) => slot && slot.kind !== "booking");
        if (!manualSlots.length) {
          blockedList.textContent = "No blocked slots yet.";
          return;
        }
        blockedList.innerHTML = manualSlots
          .map(({ slot, index }) => {
            const reason = slot.reason ? ` - ${slot.reason}` : "";
            return `<div data-index="${index}">${slot.date} ${slot.start}-${slot.end}${reason} <button data-remove="${index}" class="btn ghost" type="button">Remove</button></div>`;
          })
          .join("");
        blockedList.querySelectorAll("button[data-remove]").forEach((btn) => {
          btn.addEventListener("click", () => {
            const idx = Number(btn.dataset.remove);
            if (Number.isNaN(idx)) return;
            blockedSlots = blockedSlots.filter((_, i) => i !== idx);
            renderBlockedSlots();
            renderCalendarView();
            queueAutoSave();
          });
        });
      };

      const getSelectedRecurringDays = () => {
        if (!recurringDays) return [];
        return Array.from(recurringDays.querySelectorAll("input[type=\"checkbox\"]:checked"))
          .map((input) => Number(input.value))
          .filter((value) => !Number.isNaN(value));
      };

      const formatRecurringDays = (days) => {
        const labels = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
        return (Array.isArray(days) ? days : [])
          .map((day) => labels[day])
          .filter(Boolean)
          .join(", ");
      };

      const renderRecurringList = () => {
        if (!recurringList) return;
        if (!recurringBlocks.length) {
          recurringList.textContent = "No recurring blocks yet.";
          return;
        }
        recurringList.innerHTML = recurringBlocks
          .map((block, index) => {
            const daysLabel = formatRecurringDays(block.days);
            const timeLabel = block.all_day ? "All day" : `${block.start || ""}-${block.end || ""}`;
            const reason = block.reason ? ` - ${block.reason}` : "";
            return `<div data-index=\"${index}\">${daysLabel} | ${timeLabel}${reason} <button data-remove=\"${index}\" class=\"btn ghost\" type=\"button\">Remove</button></div>`;
          })
          .join("");
        recurringList.querySelectorAll("button[data-remove]").forEach((btn) => {
          btn.addEventListener("click", () => {
            const idx = Number(btn.dataset.remove);
            if (Number.isNaN(idx)) return;
            recurringBlocks = recurringBlocks.filter((_, i) => i !== idx);
            renderRecurringList();
            renderCalendarView();
            queueAutoSave();
          });
        });
      };

      const setBlockedListVisible = (visible) => {
        if (!blockedList || !toggleBlockedListBtn) return;
        blockedList.classList.toggle("hidden", !visible);
        toggleBlockedListBtn.textContent = visible ? "Hide blocked slots" : "Show blocked slots";
      };

      const loadAvailability = async () => {
        availabilityStatus.textContent = "";
        try {
          const response = await fetch("../api/availability.php", { cache: "no-store" });
          if (!response.ok) throw new Error("load");
          const data = await response.json();
          tourCityInput.value = data.tour_city || "";
          tourTzSelect.value = data.tour_timezone || TIMEZONES[0];
          bufferInput.value = data.buffer_minutes || 30;
          blockedSlots = normalizeBlockedSlots(data.blocked);
          recurringBlocks = Array.isArray(data.recurring) ? data.recurring : [];
          renderRecurringList();
          renderBlockedSlots();
          const todayKey = getDateKey(new Date());
          if (calendarStart) {
            calendarStart.value = todayKey;
          }
          if (calendarDay) {
            calendarDay.value = todayKey;
          }
          if (calendarMonth) {
            calendarMonth.value = todayKey.slice(0, 7);
          }
          renderCalendarView();
        } catch (_error) {
          availabilityStatus.textContent = "Unable to load availability.";
        }
      };

      const saveAvailability = async () => {
        availabilityStatus.textContent = "";
        const key = getKey();
        if (!key) {
          availabilityStatus.textContent = "Admin key required.";
          return;
        }
        const payload = {
          tour_city: tourCityInput.value.trim(),
          tour_timezone: tourTzSelect.value,
          buffer_minutes: Number(bufferInput.value || 0),
          availability_mode: "open",
          blocked: blockedSlots,
          recurring: recurringBlocks,
        };
        try {
          const response = await fetch("../api/admin/availability.php", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "X-Admin-Key": key,
            },
            body: JSON.stringify(payload),
          });
          const result = await response.json();
          if (!response.ok) throw new Error(result.error || "save");
          availabilityStatus.textContent = "Availability saved.";
        } catch (_error) {
          availabilityStatus.textContent = "Failed to save availability.";
        }
      };

      const queueAutoSave = (message = "Unsaved changes. Click Save availability.") => {
        availabilityStatus.textContent = message;
      };

      const createField = (labelText, type, value = "", placeholder = "") => {
        const wrapper = document.createElement("div");
        wrapper.className = "field";
        const label = document.createElement("label");
        label.textContent = labelText;
        const input = document.createElement("input");
        input.type = type;
        input.value = value;
        if (placeholder) input.placeholder = placeholder;
        wrapper.appendChild(label);
        wrapper.appendChild(input);
        return { wrapper, input };
      };

      const createTourRow = (entry = {}) => {
        const row = document.createElement("div");
        row.className = "editor-row";
        row.dataset.tourRow = "1";
        const startField = createField("Start date", "date", entry.start || "");
        const endField = createField("End date", "date", entry.end || "");
        const cityField = createField("City", "text", entry.city || "", "City name");
        const removeBtn = createActionButton("Remove", () => row.remove(), "btn ghost");
        row.appendChild(startField.wrapper);
        row.appendChild(endField.wrapper);
        row.appendChild(cityField.wrapper);
        row.appendChild(removeBtn);
        return row;
      };

      const createGalleryRow = (item = {}) => {
        const row = document.createElement("div");
        row.className = "editor-row gallery";
        row.dataset.galleryRow = "1";
        const srcField = createField("Photo path", "text", item.src || "", "/photos/heidi15.jpg");
        const altField = createField("Alt text", "text", item.alt || "", "Short description");
        const previewWrap = document.createElement("div");
        previewWrap.className = "gallery-preview";
        const preview = document.createElement("img");
        preview.className = "gallery-thumb";
        preview.alt = item.alt || "Preview";
        preview.src = item.src || "";
        preview.addEventListener("error", () => {
          preview.classList.add("broken");
        });
        previewWrap.appendChild(preview);
        srcField.input.addEventListener("input", () => {
          preview.classList.remove("broken");
          preview.src = srcField.input.value.trim();
        });
        altField.input.addEventListener("input", () => {
          preview.alt = altField.input.value.trim() || "Preview";
        });
        const removeBtn = createActionButton("Remove", () => row.remove(), "btn ghost");
        row.appendChild(srcField.wrapper);
        row.appendChild(altField.wrapper);
        row.appendChild(previewWrap);
        row.appendChild(removeBtn);
        return row;
      };

      const renderTourSchedule = (entries) => {
        if (!tourScheduleList) return;
        tourScheduleList.innerHTML = "";
        const list = Array.isArray(entries) ? entries : [];
        if (!list.length) {
          tourScheduleList.appendChild(createTourRow());
          return;
        }
        list.forEach((entry) => {
          tourScheduleList.appendChild(createTourRow(entry));
        });
      };

      const renderGallery = (items) => {
        if (!galleryList) return;
        galleryList.innerHTML = "";
        const list = Array.isArray(items) ? items : [];
        if (!list.length) {
          galleryList.appendChild(createGalleryRow());
          return;
        }
        list.forEach((item) => {
          galleryList.appendChild(createGalleryRow(item));
        });
      };

      const readTourScheduleFromUI = () => {
        if (!tourScheduleList) return [];
        return Array.from(tourScheduleList.querySelectorAll("[data-tour-row]"))
          .map((row) => {
            const inputs = row.querySelectorAll("input");
            const start = inputs[0]?.value || "";
            const end = inputs[1]?.value || "";
            const city = inputs[2]?.value?.trim() || "";
            return { start, end, city };
          })
          .filter((entry) => entry.start && entry.end && entry.city);
      };

      const readGalleryFromUI = () => {
        if (!galleryList) return [];
        return Array.from(galleryList.querySelectorAll("[data-gallery-row]"))
          .map((row) => {
            const inputs = row.querySelectorAll("input");
            const src = inputs[0]?.value?.trim() || "";
            const alt = inputs[1]?.value?.trim() || "";
            return { src, alt };
          })
          .filter((item) => item.src);
      };

      const loadTourSchedule = async () => {
        if (!tourScheduleStatus) return;
        tourScheduleStatus.textContent = "";
        const key = getKey();
        if (!key) {
          tourScheduleStatus.textContent = "Admin key required.";
          return;
        }
        try {
          const response = await fetch("../api/admin/tour-schedule.php", {
            headers: { ...headersWithKey() },
            cache: "no-store",
          });
          const data = await response.json();
          if (!response.ok) throw new Error(data.error || "load");
          renderTourSchedule(data.touring || []);
        } catch (_error) {
          tourScheduleStatus.textContent = "Failed to load tour schedule.";
        }
      };

      const saveTourSchedule = async () => {
        if (!tourScheduleStatus) return;
        tourScheduleStatus.textContent = "";
        const key = getKey();
        if (!key) {
          tourScheduleStatus.textContent = "Admin key required.";
          return;
        }
        const entries = readTourScheduleFromUI();
        if (!entries.length) {
          tourScheduleStatus.textContent = "Add at least one valid entry.";
          return;
        }
        try {
          const response = await fetch("../api/admin/tour-schedule.php", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "X-Admin-Key": key,
            },
            body: JSON.stringify({ touring: entries }),
          });
          const result = await response.json();
          if (!response.ok) throw new Error(result.error || "save");
          renderTourSchedule(result.touring || entries);
          tourScheduleStatus.textContent = "Tour schedule saved.";
        } catch (_error) {
          tourScheduleStatus.textContent = "Failed to save tour schedule.";
        }
      };

      const loadGallery = async () => {
        if (!galleryStatus) return;
        galleryStatus.textContent = "";
        const key = getKey();
        if (!key) {
          galleryStatus.textContent = "Admin key required.";
          return;
        }
        try {
          const response = await fetch("../api/admin/gallery.php", {
            headers: { ...headersWithKey() },
            cache: "no-store",
          });
          const data = await response.json();
          if (!response.ok) throw new Error(data.error || "load");
          renderGallery(data.items || []);
        } catch (_error) {
          galleryStatus.textContent = "Failed to load eye candy.";
        }
      };

      const saveGallery = async () => {
        if (!galleryStatus) return;
        galleryStatus.textContent = "";
        const key = getKey();
        if (!key) {
          galleryStatus.textContent = "Admin key required.";
          return;
        }
        const items = readGalleryFromUI();
        if (!items.length) {
          galleryStatus.textContent = "Add at least one eye candy photo.";
          return;
        }
        try {
          const response = await fetch("../api/admin/gallery.php", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "X-Admin-Key": key,
            },
            body: JSON.stringify({ items }),
          });
          const result = await response.json();
          if (!response.ok) throw new Error(result.error || "save");
          renderGallery(result.items || items);
          galleryStatus.textContent = "Eye candy saved.";
        } catch (_error) {
          galleryStatus.textContent = "Failed to save eye candy.";
        }
      };


      const createActionButton = (label, onClick, className = "btn ghost") => {
        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = className;
        btn.textContent = label;
        btn.addEventListener("click", onClick);
        return btn;
      };

      const formatLine = (label, value) =>
        value ? `<div class="meta"><strong>${label}:</strong> ${value}</div>` : "";

      const formatArray = (list) => (Array.isArray(list) ? list.filter(Boolean).join(", ") : "");

      const formatPaymentMethod = (value) => {
        const normalized = String(value || "").toLowerCase();
        if (normalized === "etransfer" || normalized === "interac") return "Interac e-Transfer";
        if (normalized === "wise") return "Wise";
        if (normalized === "usdc") return "USDC";
        if (normalized === "ltc" || normalized === "litecoin") return "Litecoin";
        if (normalized === "btc") return "Bitcoin";
        if (normalized === "paypal") return "PayPal";
        return value || "";
      };

      const formatCalendarStamp = (dateValue, timeValue, addMinutes = 0) => {
        const [year, month, day] = String(dateValue || "").split("-").map((value) => Number(value));
        const [hour, minute] = String(timeValue || "").split(":").map((value) => Number(value));
        if (!year || !month || !day || Number.isNaN(hour) || Number.isNaN(minute)) {
          return "";
        }
        const stamp = new Date(Date.UTC(year, month - 1, day, hour, minute));
        stamp.setUTCMinutes(stamp.getUTCMinutes() + addMinutes);
        const pad = (value) => String(value).padStart(2, "0");
        return `${stamp.getUTCFullYear()}${pad(stamp.getUTCMonth() + 1)}${pad(stamp.getUTCDate())}T${pad(
          stamp.getUTCHours()
        )}${pad(stamp.getUTCMinutes())}00`;
      };

      const buildGoogleCalendarUrl = (item) => {
        const dateValue = item.preferred_date || "";
        const timeValue = item.preferred_time || "";
        if (!dateValue || !timeValue) return "";
        const durationHours = Number(item.duration_hours || 0);
        const minutes = durationHours > 0 ? Math.round(durationHours * 60) : 60;
        const start = formatCalendarStamp(dateValue, timeValue, 0);
        const end = formatCalendarStamp(dateValue, timeValue, minutes);
        if (!start || !end) return "";
        const title = encodeURIComponent(`Booking: ${item.name || "Client"}`);
        const details = encodeURIComponent(`Booking request ${item.id || ""}`);
        const location = encodeURIComponent(item.city || "");
        const tz = encodeURIComponent(item.tour_timezone || "America/Toronto");
        return `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${title}&details=${details}&location=${location}&dates=${start}/${end}&ctz=${tz}`;
      };

      const normalizeStatus = (item) => {
        const rawStatus = String(item?.status || "pending").toLowerCase();
        const rawPayment = String(item?.payment_status || "").toLowerCase();
        const status = rawStatus === "paid" ? "accepted" : rawStatus;
        const paymentStatus = rawPayment || (rawStatus === "paid" ? "paid" : "");
        return { status, paymentStatus };
      };

      const updateStatus = async (id, status, reason = "") => {
        const key = getKey();
        if (!key) {
          requestsStatus.textContent = "Admin key required.";
          return;
        }
        requestsStatus.textContent = "";
        try {
          const response = await fetch("../api/admin/status.php", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "X-Admin-Key": key,
            },
            body: JSON.stringify({ id, status, reason }),
          });
          const result = await response.json();
          if (!response.ok) throw new Error(result.error || "status");
          requestsStatus.textContent = "Status updated.";
          await loadRequests();
          await loadAvailability();
        } catch (_error) {
          requestsStatus.textContent = "Failed to update status.";
        }
      };

      const getDownloadFilename = (response, fallback) => {
        const disposition = response.headers.get("Content-Disposition") || "";
        const match = disposition.match(/filename="?([^\";]+)"?/i);
        return match ? match[1] : fallback;
      };

      const downloadRequests = async (format) => {
        const key = getKey();
        if (!key) {
          requestsStatus.textContent = "Admin key required.";
          return;
        }
        requestsStatus.textContent = "";
        try {
          const response = await fetch(`../api/admin/export.php?format=${encodeURIComponent(format)}`, {
            headers: { "X-Admin-Key": key },
          });
          if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.error || "download");
          }
          const blob = await response.blob();
          const filename = getDownloadFilename(response, `booking-requests.${format}`);
          const url = window.URL.createObjectURL(blob);
          const link = document.createElement("a");
          link.href = url;
          link.download = filename;
          document.body.appendChild(link);
          link.click();
          link.remove();
          window.URL.revokeObjectURL(url);
          requestsStatus.textContent = "Download ready.";
        } catch (_error) {
          requestsStatus.textContent = "Failed to download.";
        }
      };

      const loadRequests = async () => {
        requestsStatus.textContent = "";
        requestsList.innerHTML = "";
        const key = getKey();
        if (!key) {
          requestsStatus.textContent = "Admin key required.";
          return;
        }
        try {
          const response = await fetch("../api/admin/requests.php", {
            headers: { ...headersWithKey() },
          });
          const data = await response.json();
          if (!response.ok) throw new Error(data.error || "load");
          const requests = Array.isArray(data.requests) ? data.requests : [];
          const filterValue = statusFilter.value;
          const filtered = requests.filter((item) => {
            const { status, paymentStatus } = normalizeStatus(item);
            if (filterValue === "all") {
              return status !== "declined";
            }
            if (filterValue === "paid") {
              return paymentStatus === "paid";
            }
            if (filterValue === "accepted") {
              return status === "accepted";
            }
            return status === filterValue;
          });
          filtered
            .slice()
            .sort((a, b) => (b.created_at || "").localeCompare(a.created_at || ""))
            .forEach((item) => {
              const { status, paymentStatus } = normalizeStatus(item);
              const card = document.createElement("div");
              card.className = "request-card";
              const badgeClass = `badge ${status}`;
              const followupCities = formatArray(item.followup_cities);
              const percentLabel = item.deposit_percent ? `${item.deposit_percent}%` : "";
              let depositLabel = "";
              if (item.deposit_amount !== undefined && item.deposit_amount !== null) {
                depositLabel = `${item.deposit_amount}${item.deposit_currency ? " " + item.deposit_currency : ""}`;
                if (percentLabel) {
                  depositLabel += ` (${percentLabel})`;
                }
              } else if (percentLabel) {
                depositLabel = percentLabel;
              }
              const followupInfo =
                item.contact_followup === "yes"
                  ? `Follow-up: ${item.contact_channel || "email"} (${followupCities || "no city"})`
                  : "Follow-up: no";
              card.innerHTML = `
                <div class="request-header">
                  <div><strong>${item.name || "Unknown"}</strong></div>
                  <div class="request-badges">
                    <span class="${badgeClass}">${status}</span>
                    ${paymentStatus === "paid" ? '<span class="badge paid">paid</span>' : ""}
                  </div>
                </div>
                ${formatLine("Email", item.email)}
                ${formatLine("Phone", item.phone)}
                ${formatLine("City", item.city)}
                ${formatLine("Type", item.booking_type)}
                ${formatLine("Outcall address", item.outcall_address)}
                ${formatLine("Experience", item.experience)}
                ${formatLine("Duration", item.duration_label)}
                ${formatLine("Preferred", `${item.preferred_date || ""} ${item.preferred_time || ""}`)}
                ${formatLine("Client TZ", item.client_timezone)}
                ${formatLine("Tour TZ", item.tour_timezone)}
                ${formatLine("Deposit", depositLabel)}
                ${formatLine("Payment status", paymentStatus === "paid" ? "paid" : "")}
                ${formatLine("Payment method", formatPaymentMethod(item.payment_method))}
                ${formatLine("Notes", item.notes)}
                <div class="meta"><strong>Decline reason:</strong> <input class="decline-reason" type="text" placeholder="Reason" value="${item.decline_reason || ""}" /></div>
                ${formatLine("Blacklist reason", item.blacklist_reason)}
                ${formatLine("Follow-up", followupInfo)}
                ${formatLine("Payment details", item.payment_link)}
                ${formatLine("Created", item.created_at)}
                ${formatLine("Updated", item.updated_at)}
                ${formatLine("Email sent", item.payment_email_sent_at)}
              `;
              const declineInput = card.querySelector(".decline-reason");
              const actions = document.createElement("div");
              actions.className = "actions";
              if (status === "pending") {
                actions.appendChild(
                  createActionButton("Accept", () => updateStatus(item.id, "accepted"), "btn")
                );
                actions.appendChild(
                  createActionButton(
                    "Blacklist",
                    () => updateStatus(item.id, "blacklisted", declineInput ? declineInput.value.trim() : ""),
                    "btn secondary"
                  )
                );
              }
              if (paymentStatus !== "paid" && status !== "blacklisted") {
                actions.appendChild(
                  createActionButton("Mark paid", () => updateStatus(item.id, "paid"), "btn")
                );
              }
              if (status !== "blacklisted") {
                actions.appendChild(
                  createActionButton(
                    "Decline",
                    () =>
                      updateStatus(item.id, "declined", declineInput ? declineInput.value.trim() : ""),
                    "btn secondary"
                  )
                );
                actions.appendChild(
                  createActionButton("Cancel", () => updateStatus(item.id, "cancelled"), "btn ghost")
                );
              }
              if (item.payment_link) {
                actions.appendChild(
                  createActionButton("Copy payment details", () => {
                    navigator.clipboard.writeText(item.payment_link || "");
                  }, "btn secondary")
                );
              }
              const calendarUrl = buildGoogleCalendarUrl(item);
              if (calendarUrl) {
                actions.appendChild(
                  createActionButton("Add to Google Calendar", () => {
                    window.open(calendarUrl, "_blank", "noopener");
                  }, "btn ghost")
                );
              }
              card.appendChild(actions);
              requestsList.appendChild(card);
            });
          if (!filtered.length) {
            requestsList.innerHTML = "<p class=\"hint\">No requests found.</p>";
          }
        } catch (_error) {
          requestsStatus.textContent = "Failed to load requests.";
        }
      };

      saveAvailabilityBtn.addEventListener("click", saveAvailability);
      if (calendarToday) {
        calendarToday.addEventListener("click", () => {
          const todayKey = getDateKey(new Date());
          if (calendarView === "day" && calendarDay) {
            calendarDay.value = todayKey;
          } else if (calendarView === "month" && calendarMonth) {
            calendarMonth.value = todayKey.slice(0, 7);
          } else if (calendarStart) {
            calendarStart.value = todayKey;
          }
          renderCalendarView();
        });
      }
      if (calendarStart) {
        calendarStart.addEventListener("change", renderCalendarView);
      }
      if (calendarDay) {
        calendarDay.addEventListener("change", renderCalendarView);
      }
      if (calendarMonth) {
        calendarMonth.addEventListener("change", renderCalendarView);
      }
      calendarViewButtons.forEach((button) => {
        button.addEventListener("click", () => {
          setCalendarView(button.dataset.calendarView || "week");
        });
      });
      tourTzSelect.addEventListener("change", () => {
        const todayKey = getDateKey(new Date());
        if (calendarStart) {
          calendarStart.value = todayKey;
        }
        if (calendarDay) {
          calendarDay.value = todayKey;
        }
        if (calendarMonth) {
          calendarMonth.value = todayKey.slice(0, 7);
        }
        renderCalendarView();
      });
      addBlockedBtn.addEventListener("click", () => {
        blockedStatus.textContent = "";
        const date = blockedDate.value;
        const start = blockedStart.value;
        const end = blockedEnd.value;
        if (!date || !start || !end) {
          blockedStatus.textContent = "Add a date, start time, and end time.";
          return;
        }
        const startMinutes = timeToMinutes(start);
        const endMinutes = timeToMinutes(end);
        if (startMinutes === null || endMinutes === null || endMinutes <= startMinutes) {
          blockedStatus.textContent = "End time must be after start time.";
          return;
        }
        for (let minutes = startMinutes; minutes < endMinutes; minutes += SLOT_MINUTES) {
          blockedSlots.push({
            date,
            start: minutesToTime(minutes),
            end: minutesToTime(Math.min(minutes + SLOT_MINUTES, endMinutes)),
            reason: blockedReason.value.trim(),
            kind: "manual",
          });
        }
        blockedDate.value = "";
        blockedStart.value = "";
        blockedEnd.value = "";
        blockedReason.value = "";
        renderBlockedSlots();
        renderCalendarView();
        queueAutoSave();
      });
      blockFullDayBtn.addEventListener("click", () => {
        blockedStatus.textContent = "";
        const date = blockedDate.value;
        if (!date) {
          blockedStatus.textContent = "Add a date first.";
          return;
        }
        const reason = blockedReason.value.trim();
        blockFullDayForDate(date, reason);
        blockedDate.value = "";
        blockedStart.value = "";
        blockedEnd.value = "";
        blockedReason.value = "";
        blockedStatus.textContent = "Full day blocked.";
        renderBlockedSlots();
        renderCalendarView();
        queueAutoSave();
      });
      blockFullRangeBtn.addEventListener("click", () => {
        blockedStatus.textContent = "";
        const startValue = blockedFullRangeStart.value;
        const endValue = blockedFullRangeEnd.value;
        if (!startValue || !endValue) {
          blockedStatus.textContent = "Add a start and end date.";
          return;
        }
        const startDate = parseDateKey(startValue);
        const endDate = parseDateKey(endValue);
        if (!startDate || !endDate || startDate > endDate) {
          blockedStatus.textContent = "End date must be after start date.";
          return;
        }
        const reason = blockedReason.value.trim();
        const current = new Date(startDate.getTime());
        while (current <= endDate) {
          blockFullDayForDate(toDateKey(current), reason);
          current.setUTCDate(current.getUTCDate() + 1);
        }
        blockedFullRangeStart.value = "";
        blockedFullRangeEnd.value = "";
        blockedReason.value = "";
        blockedStatus.textContent = "Full-day range blocked.";
        renderBlockedSlots();
        renderCalendarView();
        queueAutoSave();
      });
      addRecurringBtn.addEventListener("click", () => {
        if (!recurringStatus) return;
        recurringStatus.textContent = "";
        const days = getSelectedRecurringDays();
        if (!days.length) {
          recurringStatus.textContent = "Pick at least one day.";
          return;
        }
        const allDay = recurringAllDay && recurringAllDay.checked;
        const start = recurringStart ? recurringStart.value : "";
        const end = recurringEnd ? recurringEnd.value : "";
        if (!allDay) {
          const startMinutes = timeToMinutes(start);
          const endMinutes = timeToMinutes(end);
          if (startMinutes === null || endMinutes === null || endMinutes <= startMinutes) {
            recurringStatus.textContent = "End time must be after start time.";
            return;
          }
        }
        recurringBlocks.push({
          days,
          all_day: !!allDay,
          start: allDay ? "" : start,
          end: allDay ? "" : end,
          reason: recurringReason ? recurringReason.value.trim() : "",
        });
        if (recurringDays) {
          recurringDays.querySelectorAll("input[type=\"checkbox\"]:checked").forEach((input) => {
            input.checked = false;
          });
        }
        if (recurringAllDay) recurringAllDay.checked = false;
        if (recurringStart) recurringStart.value = "";
        if (recurringEnd) recurringEnd.value = "";
        if (recurringReason) recurringReason.value = "";
        recurringStatus.textContent = "Recurring block added.";
        renderRecurringList();
        renderCalendarView();
        queueAutoSave();
      });

      if (addTourRowBtn) {
        addTourRowBtn.addEventListener("click", () => {
          if (!tourScheduleList) return;
          tourScheduleList.appendChild(createTourRow());
        });
      }
      if (saveTourScheduleBtn) {
        saveTourScheduleBtn.addEventListener("click", saveTourSchedule);
      }
      if (addGalleryRowBtn) {
        addGalleryRowBtn.addEventListener("click", () => {
          if (!galleryList) return;
          galleryList.appendChild(createGalleryRow());
        });
      }
      if (saveGalleryBtn) {
        saveGalleryBtn.addEventListener("click", saveGallery);
      }

      if (toggleBlockedListBtn) {
        setBlockedListVisible(false);
        toggleBlockedListBtn.addEventListener("click", () => {
          const isHidden = blockedList.classList.contains("hidden");
          setBlockedListVisible(isHidden);
        });
      }
      refreshBtn.addEventListener("click", loadRequests);
      statusFilter.addEventListener("change", loadRequests);

      setCalendarView("week");
      populateTimezones();
      loadAvailability();
      loadTourSchedule();
      loadGallery();
      loadRequests();
    </script>
  </body>
</html>
