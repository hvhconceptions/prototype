<?php
declare(strict_types=1);

require __DIR__ . '/../config.php';

require_admin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['error' => 'Method not allowed'], 405);
}

$payload = get_request_body();
$tourCity = trim((string) ($payload['tour_city'] ?? ''));
$tourTz = trim((string) ($payload['tour_timezone'] ?? ''));
$buffer = isset($payload['buffer_minutes']) ? (int) $payload['buffer_minutes'] : DEFAULT_BUFFER_MINUTES;
$mode = (string) ($payload['availability_mode'] ?? 'open');
$blocked = $payload['blocked'] ?? [];
$recurring = $payload['recurring'] ?? [];

if ($tourCity === '' || $tourTz === '') {
    json_response(['error' => 'Missing tour city or timezone'], 422);
}

if (!is_array($blocked)) {
    $blocked = [];
}
if (!is_array($recurring)) {
    $recurring = [];
}

$data = [
    'tour_city' => $tourCity,
    'tour_timezone' => $tourTz,
    'buffer_minutes' => $buffer,
    'availability_mode' => $mode,
    'blocked' => $blocked,
    'recurring' => $recurring,
    'updated_at' => gmdate('c'),
];

write_json_file(DATA_DIR . '/availability.json', $data);
json_response(['ok' => true]);
